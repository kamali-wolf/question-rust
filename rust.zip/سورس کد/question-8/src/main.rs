use std::thread;
use std::sync::mpsc;
use std::time::Duration;

fn main() {
    // مثال از استفاده از threads و channels
    let (tx, rx) = mpsc::channel();

    // ایجاد یک نخ
    let handle = thread::spawn(move || {
        for i in 1..5 {
            // ارسال داده از نخ به نخ اصلی
            tx.send(i).unwrap();
            thread::sleep(Duration::from_secs(1));
        }
    });

    // دریافت داده‌ها در نخ اصلی
    for received in rx {
        println!("Received: {}", received);
    }

    // اطمینان از پایان نخ
    handle.join().unwrap();

    // مثال از futures با استفاده از tokio
    let future_example = tokio::spawn(async {
        let result = async_operation().await;
        println!("Async Operation Result: {}", result);
    });

    // اجرای futures
    tokio::runtime::Runtime::new().unwrap().block_on(future_example).unwrap();
}

// یک عملیات ناهمزمان
async fn async_operation() -> i32 {
    tokio::time::sleep(Duration::from_secs(2)).await;
    42
}
