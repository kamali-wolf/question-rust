use linfa::prelude::*;
use linfa_trees::DecisionTree;
use ndarray::Array2;

fn main() {
    // داده‌های ورودی (ویژگی‌ها)
    let x = Array2::from_shape_vec((6, 2), vec![
        1.0, 2.0,
        2.0, 3.0,
        3.0, 3.0,
        2.0, 1.0,
        3.0, 2.0,
        5.0, 4.0,
    ]).unwrap();

    // برچسب‌های خروجی
    let y = Array2::from_shape_vec((6, 1), vec![
        0.0,
        0.0,
        0.0,
        1.0,
        1.0,
        1.0,
    ]).unwrap();

    // ایجاد مدل درخت تصمیم
    let model = DecisionTree::params().fit(&x, &y).unwrap();

    // پیش‌بینی با استفاده از مدل
    let new_data = Array2::from_shape_vec((3, 2), vec![
        1.0, 2.0,
        4.0, 4.0,
        2.0, 1.0,
    ]).unwrap();

    let predictions = model.predict(&new_data).unwrap();

    // نمایش پیش‌بینی‌ها
    for (i, pred) in predictions.iter().enumerate() {
        println!("Prediction for data point {}: {}", i, pred);
    }
}
