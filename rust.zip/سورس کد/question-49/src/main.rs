#[macro_use]
extern crate diesel;
extern crate dotenv;

use diesel::prelude::*;
use dotenv::dotenv;
use std::env;

mod schema {
    table! {
        users (id) {
            id -> Integer,
            name -> Text,
            email -> Text,
        }
    }
}

#[derive(Queryable, Insertable, Debug)]
#[table_name = "users"]
struct User {
    id: i32,
    name: String,
    email: String,
}

fn establish_connection() -> SqliteConnection {
    dotenv().ok();
    let database_url = env::var("DATABASE_URL").expect("DATABASE_URL must be set");
    SqliteConnection::establish(&database_url).expect(&format!("Error connecting to {}", database_url))
}

fn create_user(conn: &SqliteConnection, name: &str, email: &str) {
    let new_user = User {
        id: 0, // id is auto-incremented
        name: name.to_string(),
        email: email.to_string(),
    };

    diesel::insert_into(schema::users::table)
        .values(&new_user)
        .execute(conn)
        .expect("Error saving new user");
}

fn read_users(conn: &SqliteConnection) {
    let results = schema::users::table.load::<User>(conn).expect("Error loading users");

    for user in results {
        println!("{:?}", user);
    }
}

fn update_user(conn: &SqliteConnection, user_id: i32, new_name: &str) {
    diesel::update(schema::users::table.find(user_id))
        .set(schema::users::name.eq(new_name))
        .execute(conn)
        .expect("Error updating user");
}

fn delete_user(conn: &SqliteConnection, user_id: i32) {
    diesel::delete(schema::users::table.find(user_id))
        .execute(conn)
        .expect("Error deleting user");
}

fn main() {
    let connection = establish_connection();

    // Create a new user
    create_user(&connection, "Alice", "alice@example.com");

    // Read users
    println!("Users:");
    read_users(&connection);

    // Update a user
    update_user(&connection, 1, "Alice Smith");

    // Delete a user
    delete_user(&connection, 1);
}
