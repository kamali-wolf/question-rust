use crate::use_cases::user_use_case::UserUseCase;

pub struct UserController {
    use_case: UserUseCase,
}

impl UserController {
    pub fn new(use_case: UserUseCase) -> Self {
        UserController { use_case }
    }

    pub fn create_user(&mut self, name: String) {
        let user = self.use_case.create_user(name);
        println!("User created: {} with ID {}", user.name, user.id);
    }
}
