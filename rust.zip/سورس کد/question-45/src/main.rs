use tonic::{transport::Server, Request, Response, Status};
use calculator::calculator_server::{Calculator, CalculatorServer};
use calculator::{AddRequest, AddResponse};

pub mod calculator {
    tonic::include_proto!("calculator");
}

#[derive(Default)]
pub struct MyCalculator {}

#[tonic::async_trait]
impl Calculator for MyCalculator {
    async fn add(
        &self,
        request: Request<AddRequest>,
    ) -> Result<Response<AddResponse>, Status> {
        let req = request.into_inner();
        let sum = req.a + req.b;
        let response = AddResponse { result: sum };
        Ok(Response::new(response))
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let addr = "[::1]:50051".parse()?;
    let calculator = MyCalculator::default();

    Server::builder()
        .add_service(CalculatorServer::new(calculator))
        .serve(addr)
        .await?;

    Ok(())
}
