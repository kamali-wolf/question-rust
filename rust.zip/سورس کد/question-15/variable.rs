fn main() {
    let x = 5; // x از نوع i32 است
    let y = 3.14; // y از نوع f64 است
    println!("x: {}, y: {}", x, y);
}
