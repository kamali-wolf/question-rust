use crate::domain::user::User;
use crate::infrastructure::user_repository::UserRepository;

pub struct UserUseCase {
    repository: UserRepository,
}

impl UserUseCase {
    pub fn new(repository: UserRepository) -> Self {
        UserUseCase { repository }
    }

    pub fn create_user(&mut self, name: String) -> User {
        let id = self.repository.next_id();
        let user = User::new(id, name);
        self.repository.save(user.clone());
        user
    }
}
