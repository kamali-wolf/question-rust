mod bst;
mod avl;

fn main() {
    // مثال از استفاده درخت جستجوی دودویی
    let mut tree = bst::BinarySearchTree::new();
    tree.insert(10);
    tree.insert(20);
    tree.insert(5);

    println!("BST Search 10: {}", tree.search(10)); // باید true باشد
    println!("BST Search 15: {}", tree.search(15)); // باید false باشد

    // مثال از استفاده درخت AVL
    let mut avl_tree = avl::AvlTree::new();
    avl_tree.insert(30);
    avl_tree.insert(20);
    avl_tree.insert(40);
    
    println!("AVL Search 20: {}", avl_tree.search(20)); // باید true باشد
    println!("AVL Search 25: {}", avl_tree.search(25)); // باید false باشد
}
