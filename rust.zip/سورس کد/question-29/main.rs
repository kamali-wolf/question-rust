fn main() {
    // تعریف یک آرایه از اعداد
    let numbers = vec![1, 2, 3, 4, 5];

    // استفاده از یک تابع درجه یک برای محاسبه مجموع اعداد
    let sum: i32 = numbers.iter().map(|&x| x * 2).sum();
    
    // استفاده از بستهبندی (closure) برای فیلتر کردن اعداد
    let filtered_numbers: Vec<i32> = numbers.iter()
        .filter(|&&x| x % 2 == 0)
        .cloned() // برای تبدیل به Vec<i32>
        .collect();
    
    // چاپ نتایج
    println!("Sum of double numbers: {}", sum);
    println!("Filtered even numbers: {:?}", filtered_numbers);
}
