struct Point {
    x: f64,
    y: f64,
}

fn main() {
    let p = Point { x: 1.0, y: 2.0 }; // نوع x و y به صورت خودکار استنباط می‌شود
    println!("Point: ({}, {})", p.x, p.y);
}
