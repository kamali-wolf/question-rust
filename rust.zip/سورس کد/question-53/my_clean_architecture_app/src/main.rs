mod domain;
mod use_cases;
mod infrastructure;
mod presentation;

use infrastructure::user_repository::UserRepository;
use use_cases::user_use_case::UserUseCase;
use presentation::user_controller::UserController;

fn main() {
    let mut repository = UserRepository::new();
    let use_case = UserUseCase::new(repository);
    let mut controller = UserController::new(use_case);

    controller.create_user("Alice".to_string());
    controller.create_user("Bob".to_string());
}
