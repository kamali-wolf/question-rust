my_clean_architecture_app/
├── Cargo.toml
└── src/
    ├── domain/
    │   ├── mod.rs
    │   └── user.rs
    ├── use_cases/
    │   ├── mod.rs
    │   └── user_use_case.rs
    ├── infrastructure/
    │   ├── mod.rs
    │   └── user_repository.rs
    ├── presentation/
    │   ├── mod.rs
    │   └── user_controller.rs
    └── main.rs
