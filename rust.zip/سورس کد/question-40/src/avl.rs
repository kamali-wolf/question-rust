pub struct Node {
    pub value: i32,
    pub height: i32,
    pub left: Option<Box<Node>>,
    pub right: Option<Box<Node>>,
}

pub struct AvlTree {
    root: Option<Box<Node>>,
}

impl AvlTree {
    pub fn new() -> Self {
        AvlTree { root: None }
    }

    pub fn insert(&mut self, value: i32) {
        self.root = Self::insert_node(self.root.take(), value);
    }

    fn insert_node(node: Option<Box<Node>>, value: i32) -> Option<Box<Node>> {
        let mut node = match node {
            Some(n) => n,
            None => return Some(Box::new(Node {
                value,
                height: 1,
                left: None,
                right: None,
            })),
        };

        if value < node.value {
            node.left = Self::insert_node(node.left, value);
        } else {
            node.right = Self::insert_node(node.right, value);
        }

        node.height = 1 + Self::max(Self::get_height(&node.left), Self::get_height(&node.right));

        let balance = Self::get_balance(&node);

        if balance > 1 && value < node.left.as_ref().unwrap().value {
            return Self::rotate_right(node);
        }
        if balance < -1 && value > node.right.as_ref().unwrap().value {
            return Self::rotate_left(node);
        }
        if balance > 1 && value > node.left.as_ref().unwrap().value {
            node.left = Some(Self::rotate_left(node.left.take().unwrap()));
            return Self::rotate_right(node);
        }
        if balance < -1 && value < node.right.as_ref().unwrap().value {
            node.right = Some(Self::rotate_right(node.right.take().unwrap()));
            return Self::rotate_left(node);
        }

        Some(node)
    }

    fn rotate_left(node: Box<Node>) -> Option<Box<Node>> {
        let mut new_root = node.right.unwrap();
        node.right = new_root.left;
        new_root.left = Some(node);
        Some(new_root)
    }

    fn rotate_right(node: Box<Node>) -> Option<Box<Node>> {
        let mut new_root = node.left.unwrap();
        node.left = new_root.right;
        new_root.right = Some(node);
        Some(new_root)
    }

    fn get_height(node: &Option<Box<Node>>) -> i32 {
        match node {
            Some(n) => n.height,
            None => 0,
        }
    }

    fn get_balance(node: &Box<Node>) -> i32 {
        Self::get_height(&node.left) - Self::get_height(&node.right)
    }

    fn max(a: i32, b: i32) -> i32 {
        if a > b { a } else { b }
    }

    pub fn search(&self, value: i32) -> bool {
        Self::search_node(&self.root, value)
    }

    fn search_node(node: &Option<Box<Node>>, value: i32) -> bool {
        match node {
            Some(n) => {
                if n.value == value {
                    true
                } else if value < n.value {
                    Self::search_node(&n.left, value)
                } else {
                    Self::search_node(&n.right, value)
                }
            }
            None => false,
        }
    }
}
