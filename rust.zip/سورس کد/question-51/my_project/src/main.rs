use xlsxwriter::{Workbook, Format};

fn main() {
    // ایجاد یک workbook جدید
    let workbook = Workbook::new("example.xlsx");

    // ایجاد یک worksheet جدید
    let mut worksheet = workbook.add_worksheet().unwrap();

    // تعریف یک فرمت برای سلول ها
    let format = Format::new().set_bold(); // فرمت بولد

    // نوشتن داده‌ها به سلول‌ها
    worksheet.write_string(0, 0, "Hello").unwrap(); // نوشتن یک رشته
    worksheet.write_number(1, 0, 42).unwrap(); // نوشتن یک عدد
    worksheet.write_string(2, 0, "World").unwrap(); // نوشتن یک رشته دیگر
    worksheet.write_string_with_format(3, 0, "Bold Text", &format).unwrap(); // نوشتن متن بولد

    // ذخیره فایل
    workbook.close().unwrap();
}
