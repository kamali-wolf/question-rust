use sqlx::sqlite::SqlitePool;
use sqlx::Error;
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug)]
struct User {
    id: i64,
    name: String,
    age: i32,
}

async fn create_user(pool: &SqlitePool, name: &str, age: i32) -> Result<User, Error> {
    let user = sqlx::query_as!(
        User,
        r#"INSERT INTO users (name, age) VALUES (?, ?) RETURNING id, name, age"#,
        name,
        age
    )
    .fetch_one(pool)
    .await?;

    Ok(user)
}

async fn read_user(pool: &SqlitePool, user_id: i64) -> Result<User, Error> {
    let user = sqlx::query_as!(
        User,
        r#"SELECT id, name, age FROM users WHERE id = ?"#,
        user_id
    )
    .fetch_one(pool)
    .await?;

    Ok(user)
}

async fn update_user(pool: &SqlitePool, user_id: i64, name: &str, age: i32) -> Result<User, Error> {
    let user = sqlx::query_as!(
        User,
        r#"UPDATE users SET name = ?, age = ? WHERE id = ? RETURNING id, name, age"#,
        name,
        age,
        user_id
    )
    .fetch_one(pool)
    .await?;

    Ok(user)
}

async fn delete_user(pool: &SqlitePool, user_id: i64) -> Result<(), Error> {
    sqlx::query!(r#"DELETE FROM users WHERE id = ?"#, user_id)
        .execute(pool)
        .await?;

    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    // ایجاد استخر پایگاه داده
    let pool = SqlitePool::connect("sqlite::memory:").await?;

    // ایجاد جدول
    sqlx::query(r#"CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age INTEGER NOT NULL)"#)
        .execute(&pool)
        .await?;

    // تست عملیات CRUD
    let user = create_user(&pool, "Alice", 30).await?;
    println!("Created User: {:?}", user);

    let user = read_user(&pool, user.id).await?;
    println!("Read User: {:?}", user);

    let user = update_user(&pool, user.id, "Alice Updated", 31).await?;
    println!("Updated User: {:?}", user);

    delete_user(&pool, user.id).await?;
    println!("Deleted User with id: {}", user.id);

    Ok(())
}
