// تعریف Trait
trait Drawable {
    fn draw(&self);
}

// پیاده‌سازی Trait برای نوع داده `Circle`
struct Circle {
    radius: f64,
}

impl Drawable for Circle {
    fn draw(&self) {
        println!("Drawing a circle with radius: {}", self.radius);
    }
}

// پیاده‌سازی Trait برای نوع داده `Square`
struct Square {
    side: f64,
}

impl Drawable for Square {
    fn draw(&self) {
        println!("Drawing a square with side: {}", self.side);
    }
}

// تابعی که از Trait استفاده می‌کند
fn render(shape: &dyn Drawable) {
    shape.draw();
}

fn main() {
    let circle = Circle { radius: 5.0 };
    let square = Square { side: 4.0 };

    // رسم اشکال
    render(&circle);
    render(&square);
}
