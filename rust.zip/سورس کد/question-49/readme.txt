1. تنظیمات اولیه پروژه
2. ایجاد مدل و جدول
3. عملیات CRUD

### مرحله 1: تنظیمات اولیه پروژه

ابتدا یک پروژه جدید Rust با استفاده از Cargo ایجاد کنید:

```bash
cargo new rust_diesel_crud
cd rust_diesel_crud
```

سپس در فایل `Cargo.toml` وابستگی‌های مورد نیاز را اضافه کنید:

```toml
[dependencies]
diesel = { version = "1.4.8", features = ["sqlite"] }
dotenv = "0.15"
```

### مرحله 2: ایجاد پایگاه داده و جدول

برای استفاده از Diesel، ابتدا باید پایگاه داده را تنظیم کنید. در اینجا از SQLite استفاده می‌کنیم. یک فایل `.env` در ریشه پروژه ایجاد کنید و آدرس پایگاه داده را مشخص کنید:

```
DATABASE_URL=test.db
```

سپس با استفاده از Diesel CLI (اگر نصب نکرده‌اید، می‌توانید آن را با `cargo install diesel_cli --no-default-features --features sqlite` نصب کنید) جدول را ایجاد کنید:

```bash
diesel setup
```

سپس یک جدول جدید برای مدل `User` ایجاد کنید:

```bash
diesel migration generate create_users
```

در پوشه `migrations`، فایل `up.sql` را به صورت زیر ویرایش کنید:

```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE
);
```

سپس با استفاده از دستور زیر مهاجرت را اعمال کنید:

```bash
diesel migration run
```

### مرحله 3: عملیات CRUD

حالا می‌توانیم کد Rust را بنویسیم. فایل `src/main.rs` را به صورت زیر ویرایش کنید:

```rust
#[macro_use]
extern crate diesel;
extern crate dotenv;

use diesel::prelude::*;
use dotenv::dotenv;
use std::env;

mod schema {
    table! {
        users (id) {
            id -> Integer,
            name -> Text,
            email -> Text,
        }
    }
}

#[derive(Queryable, Insertable, Debug)]
#[table_name = "users"]
struct User {
    id: i32,
    name: String,
    email: String,
}

fn establish_connection() -> SqliteConnection {
    dotenv().ok();
    let database_url = env::var("DATABASE_URL").expect("DATABASE_URL must be set");
    SqliteConnection::establish(&database_url).expect(&format!("Error connecting to {}", database_url))
}

fn create_user(conn: &SqliteConnection, name: &str, email: &str) {
    let new_user = User {
        id: 0, // id is auto-incremented
        name: name.to_string(),
        email: email.to_string(),
    };

    diesel::insert_into(schema::users::table)
        .values(&new_user)
        .execute(conn)
        .expect("Error saving new user");
}

fn read_users(conn: &SqliteConnection) {
    let results = schema::users::table.load::<User>(conn).expect("Error loading users");

    for user in results {
        println!("{:?}", user);
    }
}

fn update_user(conn: &SqliteConnection, user_id: i32, new_name: &str) {
    diesel::update(schema::users::table.find(user_id))
        .set(schema::users::name.eq(new_name))
        .execute(conn)
        .expect("Error updating user");
}

fn delete_user(conn: &SqliteConnection, user_id: i32) {
    diesel::delete(schema::users::table.find(user_id))
        .execute(conn)
        .expect("Error deleting user");
}

fn main() {
    let connection = establish_connection();

    // Create a new user
    create_user(&connection, "Alice", "alice@example.com");

    // Read users
    println!("Users:");
    read_users(&connection);

    // Update a user
    update_user(&connection, 1, "Alice Smith");

    // Delete a user
    delete_user(&connection, 1);
}
```

### مرحله 4: اجرای برنامه

حالا می‌توانید برنامه را اجرا کنید:

```bash
cargo run
```

این برنامه یک کاربر جدید ایجاد کرده، تمام کاربران را خوانده، نام کاربر را به‌روزرسانی کرده و در نهایت کاربر را حذف می‌کند.

### نکته

قبل از اجرای برنامه، اطمینان حاصل کنید که از **SQLite** به عنوان پایگاه داده استفاده می‌کنید و کتابخانه‌های مورد نیاز به درستی نصب شده‌اند. اگر از پایگاه داده‌های دیگر مانند PostgreSQL یا MySQL استفاده می‌کنید، باید تنظیمات مربوط به آن را در `Cargo.toml` و کد خود تغییر دهید.