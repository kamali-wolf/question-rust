// تعریف یک ساختار به نام `Animal`
struct Animal {
    name: String,
    age: u32,
}

// تعریف یک ویژگی به نام `Speak`
trait Speak {
    fn speak(&self);
}

// پیاده‌سازی ویژگی `Speak` برای ساختار `Animal`
impl Speak for Animal {
    fn speak(&self) {
        println!("{} says: Hello!", self.name);
    }
}

fn main() {
    let dog = Animal {
        name: String::from("Buddy"),
        age: 3,
    };

    // استفاده از ویژگی `Speak`
    dog.speak();
}
