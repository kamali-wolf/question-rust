fn main() {
    let x: i32 = 42;
    
    // استفاده از unsafe block
    unsafe {
        // اشاره‌گر به x
        let r: *const i32 = &x;
        
        // دسترسی به مقدار از طریق اشاره‌گر
        println!("Value of x: {}", *r);
    }
}
