use std::thread;
use std::sync::{Arc, Mutex};

fn main() {
    // استفاده از Arc برای اشتراک‌گذاری مالکیت
    let counter = Arc::new(Mutex::new(0));
    let mut handles = vec![];

    for _ in 0..10 {
        // Clone کردن Arc برای هر نخ جدید
        let counter = Arc::clone(&counter);
        
        // ایجاد نخ جدید
        let handle = thread::spawn(move || {
            // قفل کردن Mutex برای دسترسی ایمن به counter
            let mut num = counter.lock().unwrap();
            *num += 1;
        });
        
        handles.push(handle);
    }

    // منتظر ماندن برای اتمام تمام نخ‌ها
    for handle in handles {
        handle.join().unwrap();
    }

    // نمایش مقدار نهایی counter
    println!("Counter: {}", *counter.lock().unwrap());
}
