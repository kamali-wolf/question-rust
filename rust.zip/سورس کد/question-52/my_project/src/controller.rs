// src/controller.rs
use actix_web::{web, HttpResponse};
use crate::model::User;

pub async fn get_users() -> HttpResponse {
    let users = vec![
        User { id: 1, name: String::from("Alice") },
        User { id: 2, name: String::from("Bob") },
    ];

    HttpResponse::Ok().json(users)
}
