// main.rs
fn main() {
    let numbers = vec![1, 2, 3, 4, 5];

    // ایجاد یک Iterator
    let mut iter = numbers.iter();

    // تکرار بر روی عناصر با استفاده از next()
    while let Some(&number) = iter.next() {
        println!("{}", number);
    }
}
