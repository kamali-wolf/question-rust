use tokio::time::{sleep, Duration};

#[tokio::main]
async fn main() {
    println!("قبل از تأخیر");

    // تابع ناهمگام که ۲ ثانیه صبر می‌کند
    my_async_function().await;

    println!("بعد از تأخیر");
}

async fn my_async_function() {
    sleep(Duration::from_secs(2)).await; // تأخیر ۲ ثانیه‌ای
    println!("این پیام بعد از ۲ ثانیه چاپ می‌شود");
}
