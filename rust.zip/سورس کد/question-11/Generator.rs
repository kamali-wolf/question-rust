// Cargo.toml
[dependencies]
generator = "0.10"

// main.rs
use generator::Generator;

fn main() {
    let mut gen = || {
        for i in 1..=5 {
            yield i; // تولید مقدار
        }
    };

    // استفاده از Generator
    for value in gen {
        println!("{}", value);
    }
}
