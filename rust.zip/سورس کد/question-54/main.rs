// 1. Single Responsibility Principle (SRP)
struct User {
    name: String,
    email: String,
}

impl User {
    fn new(name: &str, email: &str) -> User {
        User {
            name: name.to_string(),
            email: email.to_string(),
        }
    }
}

// 2. Open/Closed Principle (OCP)
trait Notification {
    fn notify(&self, message: &str);
}

struct EmailNotification;

impl Notification for EmailNotification {
    fn notify(&self, message: &str) {
        println!("Sending email notification: {}", message);
    }
}

struct SmsNotification;

impl Notification for SmsNotification {
    fn notify(&self, message: &str) {
        println!("Sending SMS notification: {}", message);
    }
}

// 3. Liskov Substitution Principle (LSP)
fn send_notification(notification: &dyn Notification, message: &str) {
    notification.notify(message);
}

// 4. Interface Segregation Principle (ISP)
// در اینجا نیازی به پیاده‌سازی نیست زیرا ما از traits استفاده کرده‌ایم که به ما اجازه می‌دهد 
// چندین رابط خاص داشته باشیم.

fn main() {
    let user = User::new("Alice", "alice@example.com");
    
    let email_notification = EmailNotification;
    let sms_notification = SmsNotification;

    send_notification(&email_notification, "Hello, Alice!");
    send_notification(&sms_notification, "Hello, Alice!");
}
