fn main() {
    let s1 = String::from("Hello, world!"); // s1 مالک یک String است

    // Borrowing غیرقابل تغییر
    let len = calculate_length(&s1); // ارجاع به s1 بدون تغییر مالکیت آن
    println!("The length of '{}' is {}.", s1, len);

    // Borrowing قابل تغییر
    let mut s2 = String::from("Hello");
    change(&mut s2); // ارجاع قابل تغییر به s2
    println!("s2 after change: {}", s2);
}

fn calculate_length(s: &String) -> usize {
    s.len() // دسترسی به طول رشته بدون تغییر مالکیت
}

fn change(s: &mut String) {
    s.push_str(", Rust!"); // تغییر داده از طریق ارجاع قابل تغییر
}
