// تعریف یک ساختار به نام `Animal`
struct Animal {
    name: String,
    age: u32,
}

// پیاده‌سازی متدهایی برای ساختار `Animal`
impl Animal {
    fn new(name: &str, age: u32) -> Self {
        Animal {
            name: name.to_string(),
            age,
        }
    }

    fn speak(&self) {
        println!("{} says: Hello!", self.name);
    }
}

// تعریف یک trait به نام `Pet`
trait Pet {
    fn play(&self);
}

// پیاده‌سازی trait `Pet` برای ساختار `Animal`
impl Pet for Animal {
    fn play(&self) {
        println!("{} is playing!", self.name);
    }
}

// تابع اصلی
fn main() {
    // ایجاد یک شیء از نوع `Animal`
    let my_pet = Animal::new("Buddy", 3);

    // فراخوانی متد speak
    my_pet.speak();

    // فراخوانی متد play از trait `Pet`
    my_pet.play();
}
