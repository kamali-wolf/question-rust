fn main() {
    let factor = 3;

    let multiply = |x| x * factor;

    let num = 4;
    let result = multiply(num);

    println!("{} برابر با {} است.", num, result);
}
