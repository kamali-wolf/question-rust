use crate::domain::user::User;

pub struct UserRepository {
    users: Vec<User>,
    next_id: u32,
}

impl UserRepository {
    pub fn new() -> Self {
        UserRepository {
            users: Vec::new(),
            next_id: 1,
        }
    }

    pub fn next_id(&self) -> u32 {
        self.next_id
    }

    pub fn save(&mut self, user: User) {
        self.users.push(user);
        self.next_id += 1;
    }
}
