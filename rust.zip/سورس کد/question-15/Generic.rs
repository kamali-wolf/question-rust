fn print_value<T: std::fmt::Debug>(value: T) {
    println!("{:?}", value);
}

fn main() {
    print_value(10); // T از نوع i32 است
    print_value("Hello"); // T از نوع &str است
}
