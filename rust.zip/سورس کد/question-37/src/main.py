import my_rust_module

my_rust_module.hello_from_rust()
