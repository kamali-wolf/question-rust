// یک تابع که ممکن است خطا ایجاد کند
fn divide_numbers(numerator: f64, denominator: f64) -> Result<f64, String> {
    if denominator == 0.0 {
        Err(String::from("Cannot divide by zero"))
    } else {
        Ok(numerator / denominator)
    }
}

fn main() {
    let result = divide_numbers(10.0, 2.0);

    match result {
        Ok(value) => println!("Result: {}", value),
        Err(e) => println!("Error: {}", e),
    }

    // مثال دیگر با تقسیم بر صفر
    let result_zero_division = divide_numbers(10.0, 0.0);

    match result_zero_division {
        Ok(value) => println!("Result: {}", value),
        Err(e) => println!("Error: {}", e),
    }
}
