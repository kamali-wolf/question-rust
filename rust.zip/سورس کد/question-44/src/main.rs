use actix_web::{web, App, HttpServer, Responder, HttpResponse};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
struct Item {
    id: u32,
    name: String,
}

async fn get_item(item_id: web::Path<u32>) -> impl Responder {
    let item = Item {
        id: *item_id,
        name: String::from("Sample Item"),
    };
    HttpResponse::Ok().json(item)
}

async fn create_item(item: web::Json<Item>) -> impl Responder {
    let response = format!("Created item with ID: {}", item.id);
    HttpResponse::Created().body(response)
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| {
        App::new()
            .route("/item/{id}", web::get().to(get_item))
            .route("/item", web::post().to(create_item))
    })
    .bind("127.0.0.1:8080")?
    .run()
    .await
}
