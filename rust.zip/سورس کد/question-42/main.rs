use nom::{
    IResult,
    character::complete::digit1,
    combinator::map,
};

fn parse_number(input: &str) -> IResult<&str, i32> {
    map(digit1, |s: &str| s.parse::<i32>().unwrap())(input)
}

fn main() {
    let input = "12345";
    match parse_number(input) {
        Ok((remaining, number)) => {
            println!("Parsed number: {}, Remaining input: {}", number, remaining);
        }
        Err(err) => {
            println!("Error parsing: {:?}", err);
        }
    }
}
