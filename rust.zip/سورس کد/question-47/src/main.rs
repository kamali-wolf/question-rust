use std::net::{TcpListener, TcpStream};
use std::io::{Read, Write};
use std::thread;

fn handle_client(mut stream: TcpStream) {
    let mut buffer = [0; 1024];
    // خواندن داده‌ها از کلاینت
    match stream.read(&mut buffer) {
        Ok(size) => {
            println!("Received: {}", String::from_utf8_lossy(&buffer[..size]));
            // ارسال پاسخ به کلاینت
            if let Err(e) = stream.write(b"Hello from Rust server!") {
                eprintln!("Failed to write to client: {}", e);
            }
        }
        Err(e) => {
            eprintln!("Failed to read from client: {}", e);
        }
    }
}

fn main() {
    // ایجاد listener بر روی پورت 7878
    let listener = TcpListener::bind("127.0.0.1:7878").expect("Could not bind");

    println!("Server is listening on port 7878");

    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                thread::spawn(move || {
                    handle_client(stream);
                });
            }
            Err(e) => {
                eprintln!("Connection failed: {}", e);
            }
        }
    }
}
