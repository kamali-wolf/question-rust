use rayon::prelude::*;

fn main() {
    // یک آرایه از اعداد ایجاد می‌کنیم
    let numbers: Vec<i32> = (1..=1000).collect();

    // محاسبه مجموع مربعات اعداد به صورت موازی
    let sum_of_squares: i32 = numbers
        .par_iter() // استفاده از پارالل ایترتور
        .map(|&x| x * x) // هر عدد را به مربع تبدیل می‌کنیم
        .sum(); // مجموع را محاسبه می‌کنیم

    println!("Sum of squares: {}", sum_of_squares);
}
