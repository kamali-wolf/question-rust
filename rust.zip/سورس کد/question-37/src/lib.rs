use pyo3::prelude::*;

#[pyfunction]
fn hello_from_rust() {
    println!("Hello from Rust!");
}

#[pymodule]
fn my_rust_module(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(hello_from_rust, m)?)?;
    Ok(())
}
