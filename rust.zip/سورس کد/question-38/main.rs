use std::sync::Once;

struct Lazy<T> {
    init: Once,
    value: Option<T>,
}

impl<T> Lazy<T> {
    fn new() -> Self {
        Lazy {
            init: Once::new(),
            value: None,
        }
    }

    fn get<F>(&mut self, initializer: F) -> &T
    where
        F: FnOnce() -> T,
    {
        self.init.call_once(|| {
            self.value = Some(initializer());
        });

        self.value.as_ref().unwrap()
    }
}

fn main() {
    let mut lazy_value = Lazy::new();

    let value = lazy_value.get(|| {
        println!("Calculating value...");
        42 // مقدار محاسبه شده
    });

    println!("The value is: {}", value);
    // اگر دوباره از get استفاده کنیم، محاسبه دوباره انجام نمی‌شود
    let value_again = lazy_value.get(|| {
        println!("This won't be printed.");
        100
    });

    println!("The value again is: {}", value_again);
}
