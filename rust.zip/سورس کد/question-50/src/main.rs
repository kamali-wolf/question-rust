use csv::{ReaderBuilder, WriterBuilder};
use serde::{Deserialize, Serialize};
use std::error::Error;
use std::fs::File;

#[derive(Debug, Serialize, Deserialize)]
struct Record {
    id: u32,
    name: String,
    age: u32,
}

fn write_csv(file_path: &str) -> Result<(), Box<dyn Error>> {
    let mut wtr = WriterBuilder::new().from_path(file_path)?;

    let records = vec![
        Record { id: 1, name: "Alice".to_string(), age: 30 },
        Record { id: 2, name: "Bob".to_string(), age: 25 },
        Record { id: 3, name: "Charlie".to_string(), age: 35 },
    ];

    for record in records {
        wtr.serialize(record)?;
    }

    wtr.flush()?;
    Ok(())
}

fn read_csv(file_path: &str) -> Result<(), Box<dyn Error>> {
    let file = File::open(file_path)?;
    let mut rdr = ReaderBuilder::new().from_reader(file);

    for result in rdr.deserialize() {
        let record: Record = result?;
        println!("{:?}", record);
    }

    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let file_path = "data.csv";

    // نوشتن داده‌ها به فایل CSV
    write_csv(file_path)?;

    // خواندن داده‌ها از فایل CSV
    read_csv(file_path)?;

    Ok(())
}
