struct MaxHeap {
    data: Vec<i32>,
}

impl MaxHeap {
    fn new() -> Self {
        MaxHeap { data: Vec::new() }
    }

    fn parent(&self, index: usize) -> Option<usize> {
        if index == 0 {
            None
        } else {
            Some((index - 1) / 2)
        }
    }

    fn left_child(&self, index: usize) -> Option<usize> {
        let left = 2 * index + 1;
        if left < self.data.len() {
            Some(left)
        } else {
            None
        }
    }

    fn right_child(&self, index: usize) -> Option<usize> {
        let right = 2 * index + 2;
        if right < self.data.len() {
            Some(right)
        } else {
            None
        }
    }

    fn insert(&mut self, value: i32) {
        self.data.push(value);
        self.bubble_up(self.data.len() - 1);
    }

    fn bubble_up(&mut self, index: usize) {
        let mut idx = index;
        while let Some(parent_idx) = self.parent(idx) {
            if self.data[idx] > self.data[parent_idx] {
                self.data.swap(idx, parent_idx);
                idx = parent_idx;
            } else {
                break;
            }
        }
    }

    fn extract_max(&mut self) -> Option<i32> {
        if self.data.is_empty() {
            return None;
        }
        let max_value = self.data[0];
        let last_value = self.data.pop().unwrap();
        if !self.data.is_empty() {
            self.data[0] = last_value;
            self.bubble_down(0);
        }
        Some(max_value)
    }

    fn bubble_down(&mut self, index: usize) {
        let mut idx = index;
        loop {
            let left = self.left_child(idx);
            let right = self.right_child(idx);
            let mut largest = idx;

            if let Some(left_idx) = left {
                if self.data[left_idx] > self.data[largest] {
                    largest = left_idx;
                }
            }

            if let Some(right_idx) = right {
                if self.data[right_idx] > self.data[largest] {
                    largest = right_idx;
                }
            }

            if largest != idx {
                self.data.swap(idx, largest);
                idx = largest;
            } else {
                break;
            }
        }
    }

    fn peek(&self) -> Option<i32> {
        self.data.get(0).copied()
    }

    fn display(&self) {
        for value in &self.data {
            print!("{} ", value);
        }
        println!();
    }
}

fn main() {
    let mut heap = MaxHeap::new();
    heap.insert(10);
    heap.insert(20);
    heap.insert(5);
    heap.insert(30);
    heap.insert(15);

    println!("Current Max Heap:");
    heap.display();

    println!("Max value extracted: {:?}", heap.extract_max());
    println!("Max value after extraction:");
    heap.display();
}
